# PAAW 的架構

> **問題分類**：architecture　|　**信心程度**：high　|　**回答深度**：standard

PAAW（Personal AI Assistant Workspace）是一個基於 **npm workspaces monorepo** 的系統，核心目標是讓知識工作者用 AI 打造自己的工具，形成「人用 AI 做工具 → AI 幫記資料 → AI 放大記的資料」的能力飛輪。

---

## 一、Monorepo 分層結構

PAAW 採用 monorepo 架構，分為 7 個核心 package，各自職責明確：

| Package | 職責 | 技術 |
|---|---|---|
| **`packages/ui`** | React 前端介面（Dashboard、Chat、Skill Lab） | React 18 + Vite + Tailwind CSS + i18n |
| **`packages/server`** | HTTP + WebSocket API server | Node.js |
| **`packages/shared`** | 共用型別、工具函式、JSON Schema | TypeScript |
| **`packages/db`** | 資料庫層（SQLite + Kysely ORM） | SQLite + Kysely |
| **`packages/context`** | Context 組裝、記憶管理、知識蒸餾 | TypeScript |
| **`packages/engine`** | Skill/Workflow 執行引擎 + Tool Engine | TypeScript |
| **`packages/data`** | Runtime data（SQLite 資料庫檔案） | SQLite |

---

## 二、核心概念與資料流

PAAW 有 5 個核心概念彼此組合：

```
使用者 ─→ Chat ─→ Tool Engine ─→ Skill ─→ Runner ─→ 結果
                                          ↑
                              App / Workflow / CronJob 也能觸發
```

### 1. AI Crew — AI 團隊
每個成員有角色、技能、個性，定義存放在 `data/crews/`（JSON 格式）。

### 2. Skill — 最小能力單元
- 由 `SKILL.md` 定義，包含 Purpose、Inputs、Deterministic Script、Output Contract
- 透過 **4 種 Runner** 執行：
  - **`PromptRunner`** — LLM prompt 執行，支援 `{{template}}` 變數替換
  - **`DataRunner`** — 資料 CRUD（create / read / update / delete / search）
  - **`ApiRunner`** — 外部 API 呼叫，支援 bearer token / API key 認證
  - **`ScriptRunner`** — 沙箱內執行 JavaScript / Shell / Python 腳本
- 所有執行記錄寫入 `runs` 表，追蹤 status、duration、input/output

### 3. App — 應用
- 資料驅動或 Skill-based
- 自動產生聊天 Tool，每個 App 在聊天視窗都可用
- 透過 API Key 提供外部存取（`api_keys` 表，key 以 hash 儲存）

### 4. Workflow — 工作流
- 目前為 **線性管道**（A → B → C），每個 node 的 output 餵入下一個 node 的 input
- 支援 template 變數解析：`{{nodeId.output.field}}`
- 錯誤處理策略：`stop`（中斷）/ `skip`（跳過）/ `retry`（重試）

### 5. CronJob — 排程
- 定時觸發 Skill 或 App
- 執行結果記錄在 `cron_logs` 表

---

## 三、Tool Engine — 聊天背後的隱藏 CLI

Tool Engine 是 Chat 與 Skill 之間的核心橋樑，採用 **ReAct loop** 架構：

```
Chat Route ──→ Tool Engine
                 │
          ┌──────┴──────┐
          │  Provider    │──→ LLM API
          │  Adapter     │
          └──────┬───────┘
                 │
          ┌──────┴───────┐
          │  ReAct Loop   │（最多 N 輪，預設 5）
          └──────┬───────┘
                 │
          ┌──────┴───────┐
          │  Tool         │──→ App Tools / Skill
          │  Registry     │
          └──────────────┘
```

**運作流程**：
1. 使用者輸入訊息 → Tool Engine 組裝 messages（system + user）
2. 送給 Provider Adapter（OpenAI-compatible）→ 取得 LLM 回應
3. 若 LLM 回傳 tool calls → 透過 Tool Registry 執行對應工具
4. 工具結果回傳 → 再送給 LLM，進入下一輪
5. 直到 LLM 不再呼叫工具，或達到最大輪數（預設 5 輪）

---

## 四、Context Engine — 讓 AI 擁有記憶

Context Engine 負責在每次 AI 回應前組裝 context，分為三大元件：

### Context Assembler（即時組裝）
每次對話前，組裝一個 `ContextBundle`（token budget ~4000 tokens）：
- **Profile**（≤500 tokens）— 使用者偏好、長期記憶
- **Recent Messages**（最近 10 則）— 對話上下文
- **Relevant Memories**（≤1500 tokens）— 依關鍵字搜尋的相關記憶
- **Active Tasks** — 進行中的任務
- **Available Skills** — 可用的 Skill 清單

### Memory Store（記憶儲存）
四層記憶架構，全部存在 `memory` 表：
- **`profile`** — 長期使用者偏好（永久）
- **`interaction`** — 互動中提取的偏好（從對話萃取）
- **`working`** — 短期工作記憶（有過期時間，自動清理）
- **`knowledge`** — 知識庫記憶

### Refinery（知識蒸餾）
三個排程層級，從對話中萃取知識：
- **Realtime** — 每次對話後即時提取偏好（regex pattern matching）
- **Daily** — 每日彙總，更新 profile，存入 `daily_summaries` 表
- **Weekly** — 每週洞察，分析 intent 使用模式

---

## 五、資料庫架構

PAAW 使用 **SQLite + Kysely ORM**，核心資料表包括：

| 資料表 | 用途 |
|---|---|
| `runs` | Skill 執行記錄（含 input/output/status/duration） |
| `conversations` | 對話 session（chat / skill-lab / app-lab） |
| `chat_messages` | 對話訊息（含 intent、token 用量、latency） |
| `data_store` | App 的資料儲存（soft delete） |
| `memory` | 四層記憶系統（含 embedding vector 欄位） |
| `cron_logs` | 排程執行記錄 |
| `api_keys` | App 的外部 API key（hash 儲存） |
| `daily_summaries` | 每日摘要（含 highlights、intent counts、mood） |
| `skill_meta` | Skill 統計（總執行數、成功率、平均耗時） |

---

## 六、使用者資料目錄

```
data/
├── crews/          ← AI 成員定義（JSON）
├── skills/         ← Skill 定義（SKILL.md）
│   ├── building/       ← 開發中
│   ├── physical-skill/ ← 已發佈
│   └── input-prompt/   ← 自動產生的 inputs.json
├── apps/           ← App 定義 + 資料
├── config/         ← Provider、使用者設定
├── chats/          ← 對話歷史
└── db/             ← SQLite 資料庫檔案
```

---

## 總結

PAAW 的架構核心思想是：**用宣告式定義（SKILL.md）描述能力，由統一的 Engine 負責執行，用 Context Engine 賦予記憶，用 Tool Engine 把一切串進聊天介面。** 這使得使用者不需要寫程式，只需定義 Skill 的意圖和輸出，就能組合出複雜的自動化工作流。

---

📚 **參考來源：**
- `README.md`
- `packages/engine/src/runner/index.ts`
- `packages/engine/src/tool-engine/index.ts`
- `packages/engine/src/workflow/index.ts`
- `packages/shared/src/types/index.ts`
- `packages/context/src/assembler.ts`
- `packages/context/src/memory/memory-store.ts`
- `packages/context/src/refinery/refinery.ts`
- `packages/db/src/types.ts`

---

### 建議的後續問題
1. PAAW 的 Skill 執行引擎（4 種 Runner）具體怎麼運作？
2. Tool Engine 的 ReAct loop 在實際對話中如何觸發 Skill？
3. Context Engine 的四層記憶系統怎麼影響 AI 的回答品質？
4. 怎麼建立一個新的 Skill 並加入 PAAW？
5. PAAW 的 Workflow 引擎支援哪些執行模式？
