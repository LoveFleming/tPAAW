翻譯結果如下：

---

「**你好世界**」翻譯成英文是：**Hello World**

| 原文 | 語言 | 翻譯 | 語言 |
|------|------|------|------|
| 你好世界 | 中文 (繁體) | Hello World | 英文 |

輸出檔案已儲存至：`/Users/steward/App/aioc/data/skills/building/translate/test-output/translation.json`